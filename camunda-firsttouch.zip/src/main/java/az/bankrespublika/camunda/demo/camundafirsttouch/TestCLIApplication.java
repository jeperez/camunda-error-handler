/*
 * Copyright (c) 2019.
 * For internal use only — Not for external distribution.
 * It contains proprietary and confidential information.
 * This source code is the property of Bank Respublika ©1992 - 2019.
 * If you encountered with this code on public resources, please contact with admin@bankrespublika.az
 *
 * az.bankrespublika.camunda.demo.camundafirsttouch.TestCLIApplication
 *
 * @Project:  camunda-firsttouch
 * @Author:   RashadKh
 * @Created:  8/11/2019
 */

package az.bankrespublika.camunda.demo.camundafirsttouch;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.ProcessEngineConfiguration;
import org.camunda.bpm.engine.RepositoryService;
import org.camunda.bpm.engine.TaskService;
import org.camunda.bpm.engine.impl.history.HistoryLevel;
import org.camunda.bpm.engine.impl.history.HistoryLevelFull;
import org.springframework.beans.factory.annotation.Autowired;

public class TestCLIApplication {

    @Autowired
    ProcessEngine processEngine;


    public static void main(String[] args) {

        ProcessEngineConfiguration processEngineConfiguration = ProcessEngineConfiguration.createStandaloneProcessEngineConfiguration();
        ProcessEngine processEngine = processEngineConfiguration.setJdbcDriver("org.postgresql.Driver")
                .setJdbcPassword("1")
                .setJdbcUsername("postgres")
                .setJdbcUrl("jdbc:postgresql://ubuntu-dc:5432/camunda2")
                .setHistory(ProcessEngineConfiguration.HISTORY_FULL)
                .buildProcessEngine();

        TaskService taskService = processEngine.getTaskService();
        RepositoryService repositoryService = processEngine.getRepositoryService();
        processEngine.getHistoryService().createHistoricDetailQuery().orderByTime().asc().list().forEach(System.out::println);

        System.err.println(processEngine.getName());

    }
}
