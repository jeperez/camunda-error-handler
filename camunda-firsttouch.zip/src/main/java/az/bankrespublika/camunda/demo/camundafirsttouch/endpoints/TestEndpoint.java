/*
 * Copyright (c) 2019.
 * For internal use only — Not for external distribution.
 * It contains proprietary and confidential information.
 * This source code is the property of Bank Respublika ©1992 - 2019.
 * If you encountered with this code on public resources, please contact with admin@bankrespublika.az
 *
 * az.bankrespublika.camunda.demo.camundafirsttouch.endpoints.TestEndpoint
 *
 * @Project:  camunda-firsttouch
 * @Author:   RashadKh
 * @Created:  8/8/2019
 */

package az.bankrespublika.camunda.demo.camundafirsttouch.endpoints;

import org.camunda.bpm.engine.ProcessEngine;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestEndpoint{

    @Autowired
    RuntimeService runtimeService;

    @GetMapping(path = "x")
    public String test(){
        try{
            ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("account_close_flow");
            System.err.println(processInstance.getId());
        }catch (Exception ex){

        }
        return "hi";
    }
}
